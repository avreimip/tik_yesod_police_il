﻿var pageEditor = {
    "setting": {},
    "pageAnnos": [[]]
};
//"pageAnnos": [[]] 如果这里不是这样的结构会影响到语音助手的设置
